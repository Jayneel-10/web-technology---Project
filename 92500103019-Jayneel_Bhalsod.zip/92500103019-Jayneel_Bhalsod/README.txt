MCU STREAM - COMPLETED WEBSITE FILES

HOW TO OPEN
1. Extract this ZIP folder.
2. Open index.html in Chrome, Edge, or Firefox.
3. The index page opens the supplied interactive 10-page preview.
4. The individual HTML pages are included separately in the same folder.

POSTER ASSETS
The assets/ folder contains 12 local JPEG poster images used by the movie and series cards.
Movies: Iron Man, The Incredible Hulk, Iron Man 2, Thor, Captain America: The First Avenger, The Avengers, Black Panther, Avengers: Endgame, Doctor Strange.
Series: Loki, WandaVision, Moon Knight.

The posters are stored locally, so the pages do not need an internet connection to display them.
